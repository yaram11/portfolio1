import 'package:flutter/material.dart';

class CustomWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Text(
      'flutter uses Dart',
      style: TextStyle(color: Colors.purple),
    );
  }
}
