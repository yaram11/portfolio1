package com.example.aaam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
